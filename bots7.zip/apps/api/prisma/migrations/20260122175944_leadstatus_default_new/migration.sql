-- AlterTable
ALTER TABLE "Conversation" ALTER COLUMN "leadStatus" SET DEFAULT 'NEW';
